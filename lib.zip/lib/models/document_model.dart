class Document {
  final int id;
  final String title;
  final String contentType;
  final String? summary;
  final DateTime createdAt;

  Document({
    required this.id,
    required this.title,
    required this.contentType,
    this.summary,
    required this.createdAt,
  });

  factory Document.fromJson(Map<String, dynamic> json) {
    return Document(
      id: json['id'],
      title: json['title'],
      contentType: json['content_type'],
      summary: json['summary'],
      createdAt: DateTime.parse(json['created_at']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'content_type': contentType,
      'summary': summary,
      'created_at': createdAt.toIso8601String(),
    };
  }
}