String formatDate(DateTime date) {
  return "${date.day}/${date.month}/${date.year}";
}